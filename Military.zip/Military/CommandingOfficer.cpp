#include "CommandingOfficer.h"

CommandingOfficer::CommandingOfficer(string name, int y) : Soldier(name,y) {
  subordinates.clear(); 
  n = 0; /* has no subordinates to begin with */
}

void CommandingOfficer::addSubordinate(Soldier *s) {
  if (n < 100) {
    subordinates.push_back(s);
    n++;
  }
  else {
    cout << "full complement\n";
  }
}


void CommandingOfficer::show_soldiers() {
  cout << "subordinates of " << name << " are\n";
  for (int i = 0; i < n; i++) {
    cout << "   ";
    subordinates[i]->show_me();
  }
}


