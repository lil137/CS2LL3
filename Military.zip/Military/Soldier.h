#include <string>
#include <iostream>

using namespace std;

class Soldier {

public:
  Soldier(void);
  Soldier(string name, int y); // initialises name and years
  void show_me(void); // shows name and years 
  string name;
  int years;


};

