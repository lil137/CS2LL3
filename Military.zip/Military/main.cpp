#include "CommandingOfficer.h"


main () {
  Soldier s1("smith",22);
  Soldier s2("jones",22);
  CommandingOfficer co("oneill",25);

  co.addSubordinate(&s1);
  co.addSubordinate(&s2);

  s1.show_me();
  co.show_me();
  co.show_soldiers();

  s1.name = "smithee";
  co.show_soldiers();
}
