#include "Soldier.h"
#include <vector>
using namespace std;

class CommandingOfficer : public Soldier {
private:
  vector<Soldier *> subordinates;
  int n;

public:
  CommandingOfficer(void);
  CommandingOfficer(string n, int y);
  void show_soldiers(void);
  void addSubordinate(Soldier *s);

};
