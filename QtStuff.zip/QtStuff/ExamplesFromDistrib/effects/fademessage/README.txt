The background is taken from a public domain photo at:
http://www.photos8.com/view/windows_problem_blue-800x600.html
